@extends('layouts.app')

@section('content')
<h2>Create Forum Post</h2>
<form action="{{ route('forum.store') }}" method="POST">
    @csrf
    <div class="mb-3">
        <label>Title (EN):</label>
        <input type="text" name="title_en" class="form-control" required>
    </div>
    <div class="mb-3">
        <label>Title (FR):</label>
        <input type="text" name="title_fr" class="form-control" required>
    </div>
    <div class="mb-3">
        <label>Content (EN):</label>
        <textarea name="content_en" class="form-control" rows="4" required></textarea>
    </div>
    <div class="mb-3">
        <label>Content (FR):</label>
        <textarea name="content_fr" class="form-control" rows="4" required></textarea>
    </div>
    <button class="btn btn-success">Publish</button>
</form>
@endsection
