@extends('layouts.app')

@section('content')
<h2>{{ app()->getLocale() == 'fr' ? $forum->title_fr : $forum->title_en }}</h2>

<p>{{ app()->getLocale() == 'fr' ? $forum->content_fr : $forum->content_en }}</p>

<a href="{{ route('forum.index') }}" class="btn btn-secondary mt-3">Back to Forum</a>
@endsection
