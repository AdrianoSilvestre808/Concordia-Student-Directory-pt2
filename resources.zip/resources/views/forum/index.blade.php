@extends('layouts.app')

@section('content')
<h2>{{ __('messages.forum') }}</h2>

<a href="{{ route('forum.create') }}" class="btn btn-primary mb-3">New Post</a>

@foreach($posts as $post)
    <div class="mb-4 border p-3">
        <h4>
            <a href="{{ route('forum.show', $post) }}">
                {{ app()->getLocale() == 'fr' ? $post->title_fr : $post->title_en }}
            </a>
        </h4>
        <p>{{ app()->getLocale() == 'fr' ? $post->content_fr : $post->content_en }}</p>

        @if($post->user_id === Session::get('user_id'))
            <a href="{{ route('forum.edit', $post) }}" class="btn btn-sm btn-warning">Edit</a>

            <form action="{{ route('forum.destroy', $post) }}" method="POST" class="d-inline">
                @csrf
                @method('DELETE')
                <button class="btn btn-sm btn-danger">Delete</button>
            </form>
        @endif
    </div>
@endforeach
@endsection
