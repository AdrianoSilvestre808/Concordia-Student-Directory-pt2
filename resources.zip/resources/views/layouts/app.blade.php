<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Concordia Student Directory</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark px-4">
        <a class="navbar-brand" href="{{ route('students.index') }}">Student Directory</a>

        <div class="ms-3">
    <a href="{{ route('lang.switch', ['locale' => 'en']) }}" class="btn btn-sm btn-outline-light">EN</a>
    <a href="{{ route('lang.switch', ['locale' => 'fr']) }}" class="btn btn-sm btn-outline-light">FR</a>
</div>

        
        <div class="ms-auto d-flex align-items-center">
            @if(Session::has('user_id'))
                <form action="{{ route('logout') }}" method="POST" class="d-inline">
                    @csrf
                    <button type="submit" class="btn btn-outline-light btn-sm">Logout</button>
                </form>
            @else
                <a href="{{ route('login.form') }}" class="btn btn-outline-light btn-sm">Login</a>
            @endif
        </div>
    </nav>

    <div class="container py-4">
        @yield('content')
    </div>
</body>
</html>
