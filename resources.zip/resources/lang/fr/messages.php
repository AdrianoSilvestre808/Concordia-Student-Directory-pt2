<?php

return [
    'welcome' => 'Bienvenue dans l\'annuaire des étudiants',
    'login' => 'Connexion',
    'logout' => 'Déconnexion',
    'students' => 'Étudiants',
    'forum' => 'Forum',
];
