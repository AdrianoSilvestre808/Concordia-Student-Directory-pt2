<?php

return [
    'welcome' => 'Welcome to the Student Directory',
    'login' => 'Login',
    'logout' => 'Logout',
    'students' => 'Students',
    'forum' => 'Forum',
];
